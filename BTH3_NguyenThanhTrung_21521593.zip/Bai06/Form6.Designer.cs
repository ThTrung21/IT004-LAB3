﻿namespace Bai06
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bN7 = new System.Windows.Forms.Button();
            this.bN8 = new System.Windows.Forms.Button();
            this.bN9 = new System.Windows.Forms.Button();
            this.bN4 = new System.Windows.Forms.Button();
            this.bN5 = new System.Windows.Forms.Button();
            this.bN6 = new System.Windows.Forms.Button();
            this.bN1 = new System.Windows.Forms.Button();
            this.bN2 = new System.Windows.Forms.Button();
            this.bN3 = new System.Windows.Forms.Button();
            this.bN0 = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.bDecimal = new System.Windows.Forms.Button();
            this.bAdd = new System.Windows.Forms.Button();
            this.bSub = new System.Windows.Forms.Button();
            this.bMul = new System.Windows.Forms.Button();
            this.bDiv = new System.Windows.Forms.Button();
            this.bEqual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.textBox1.Location = new System.Drawing.Point(10, 42);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(328, 29);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bN7
            // 
            this.bN7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN7.Location = new System.Drawing.Point(38, 140);
            this.bN7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN7.Name = "bN7";
            this.bN7.Size = new System.Drawing.Size(44, 50);
            this.bN7.TabIndex = 1;
            this.bN7.Text = "7";
            this.bN7.UseVisualStyleBackColor = true;
            this.bN7.Click += new System.EventHandler(this.bN7_Click);
            // 
            // bN8
            // 
            this.bN8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN8.Location = new System.Drawing.Point(104, 140);
            this.bN8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN8.Name = "bN8";
            this.bN8.Size = new System.Drawing.Size(44, 50);
            this.bN8.TabIndex = 2;
            this.bN8.Text = "8";
            this.bN8.UseVisualStyleBackColor = true;
            this.bN8.Click += new System.EventHandler(this.bN8_Click);
            // 
            // bN9
            // 
            this.bN9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN9.Location = new System.Drawing.Point(171, 140);
            this.bN9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN9.Name = "bN9";
            this.bN9.Size = new System.Drawing.Size(44, 50);
            this.bN9.TabIndex = 3;
            this.bN9.Text = "9";
            this.bN9.UseVisualStyleBackColor = true;
            this.bN9.Click += new System.EventHandler(this.bN9_Click);
            // 
            // bN4
            // 
            this.bN4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN4.Location = new System.Drawing.Point(38, 214);
            this.bN4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN4.Name = "bN4";
            this.bN4.Size = new System.Drawing.Size(44, 50);
            this.bN4.TabIndex = 4;
            this.bN4.Text = "4";
            this.bN4.UseVisualStyleBackColor = true;
            this.bN4.Click += new System.EventHandler(this.bN4_Click);
            // 
            // bN5
            // 
            this.bN5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN5.Location = new System.Drawing.Point(104, 214);
            this.bN5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN5.Name = "bN5";
            this.bN5.Size = new System.Drawing.Size(44, 50);
            this.bN5.TabIndex = 5;
            this.bN5.Text = "5";
            this.bN5.UseVisualStyleBackColor = true;
            this.bN5.Click += new System.EventHandler(this.bN5_Click);
            // 
            // bN6
            // 
            this.bN6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN6.Location = new System.Drawing.Point(171, 214);
            this.bN6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN6.Name = "bN6";
            this.bN6.Size = new System.Drawing.Size(44, 50);
            this.bN6.TabIndex = 6;
            this.bN6.Text = "6";
            this.bN6.UseVisualStyleBackColor = true;
            this.bN6.Click += new System.EventHandler(this.bN6_Click);
            // 
            // bN1
            // 
            this.bN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN1.Location = new System.Drawing.Point(38, 287);
            this.bN1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN1.Name = "bN1";
            this.bN1.Size = new System.Drawing.Size(44, 50);
            this.bN1.TabIndex = 7;
            this.bN1.Text = "1";
            this.bN1.UseVisualStyleBackColor = true;
            this.bN1.Click += new System.EventHandler(this.bN1_Click);
            // 
            // bN2
            // 
            this.bN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN2.Location = new System.Drawing.Point(104, 287);
            this.bN2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN2.Name = "bN2";
            this.bN2.Size = new System.Drawing.Size(44, 50);
            this.bN2.TabIndex = 8;
            this.bN2.Text = "2";
            this.bN2.UseVisualStyleBackColor = true;
            this.bN2.Click += new System.EventHandler(this.bN2_Click);
            // 
            // bN3
            // 
            this.bN3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN3.Location = new System.Drawing.Point(171, 287);
            this.bN3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN3.Name = "bN3";
            this.bN3.Size = new System.Drawing.Size(44, 50);
            this.bN3.TabIndex = 9;
            this.bN3.Text = "3";
            this.bN3.UseVisualStyleBackColor = true;
            this.bN3.Click += new System.EventHandler(this.bN3_Click);
            // 
            // bN0
            // 
            this.bN0.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bN0.Location = new System.Drawing.Point(104, 355);
            this.bN0.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bN0.Name = "bN0";
            this.bN0.Size = new System.Drawing.Size(44, 50);
            this.bN0.TabIndex = 10;
            this.bN0.Text = "0";
            this.bN0.UseVisualStyleBackColor = true;
            this.bN0.Click += new System.EventHandler(this.bN0_Click);
            // 
            // bClear
            // 
            this.bClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bClear.Location = new System.Drawing.Point(171, 357);
            this.bClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(44, 47);
            this.bClear.TabIndex = 11;
            this.bClear.Text = "C";
            this.bClear.UseVisualStyleBackColor = true;
            this.bClear.Click += new System.EventHandler(this.bClear_Click);
            // 
            // bDecimal
            // 
            this.bDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.bDecimal.Location = new System.Drawing.Point(38, 355);
            this.bDecimal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bDecimal.Name = "bDecimal";
            this.bDecimal.Size = new System.Drawing.Size(44, 50);
            this.bDecimal.TabIndex = 12;
            this.bDecimal.Text = ".";
            this.bDecimal.UseVisualStyleBackColor = true;
            this.bDecimal.Click += new System.EventHandler(this.bDecimal_Click);
            // 
            // bAdd
            // 
            this.bAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bAdd.Location = new System.Drawing.Point(233, 140);
            this.bAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bAdd.Name = "bAdd";
            this.bAdd.Size = new System.Drawing.Size(44, 50);
            this.bAdd.TabIndex = 13;
            this.bAdd.Text = "+";
            this.bAdd.UseVisualStyleBackColor = true;
            this.bAdd.Click += new System.EventHandler(this.bAdd_Click);
            // 
            // bSub
            // 
            this.bSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bSub.Location = new System.Drawing.Point(233, 214);
            this.bSub.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bSub.Name = "bSub";
            this.bSub.Size = new System.Drawing.Size(44, 50);
            this.bSub.TabIndex = 14;
            this.bSub.Text = "-";
            this.bSub.UseVisualStyleBackColor = true;
            this.bSub.Click += new System.EventHandler(this.bSub_Click);
            // 
            // bMul
            // 
            this.bMul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bMul.Location = new System.Drawing.Point(233, 287);
            this.bMul.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bMul.Name = "bMul";
            this.bMul.Size = new System.Drawing.Size(44, 50);
            this.bMul.TabIndex = 15;
            this.bMul.Text = "x";
            this.bMul.UseVisualStyleBackColor = true;
            this.bMul.Click += new System.EventHandler(this.bMul_Click);
            // 
            // bDiv
            // 
            this.bDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bDiv.Location = new System.Drawing.Point(233, 353);
            this.bDiv.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bDiv.Name = "bDiv";
            this.bDiv.Size = new System.Drawing.Size(44, 50);
            this.bDiv.TabIndex = 16;
            this.bDiv.Text = "/";
            this.bDiv.UseVisualStyleBackColor = true;
            this.bDiv.Click += new System.EventHandler(this.bDiv_Click);
            // 
            // bEqual
            // 
            this.bEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.bEqual.Location = new System.Drawing.Point(291, 353);
            this.bEqual.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bEqual.Name = "bEqual";
            this.bEqual.Size = new System.Drawing.Size(44, 50);
            this.bEqual.TabIndex = 17;
            this.bEqual.Text = "=";
            this.bEqual.UseVisualStyleBackColor = true;
            this.bEqual.Click += new System.EventHandler(this.bEqual_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 415);
            this.Controls.Add(this.bEqual);
            this.Controls.Add(this.bDiv);
            this.Controls.Add(this.bMul);
            this.Controls.Add(this.bSub);
            this.Controls.Add(this.bAdd);
            this.Controls.Add(this.bDecimal);
            this.Controls.Add(this.bClear);
            this.Controls.Add(this.bN0);
            this.Controls.Add(this.bN3);
            this.Controls.Add(this.bN2);
            this.Controls.Add(this.bN1);
            this.Controls.Add(this.bN6);
            this.Controls.Add(this.bN5);
            this.Controls.Add(this.bN4);
            this.Controls.Add(this.bN9);
            this.Controls.Add(this.bN8);
            this.Controls.Add(this.bN7);
            this.Controls.Add(this.textBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form6";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bN7;
        private System.Windows.Forms.Button bN8;
        private System.Windows.Forms.Button bN9;
        private System.Windows.Forms.Button bN4;
        private System.Windows.Forms.Button bN5;
        private System.Windows.Forms.Button bN6;
        private System.Windows.Forms.Button bN1;
        private System.Windows.Forms.Button bN2;
        private System.Windows.Forms.Button bN3;
        private System.Windows.Forms.Button bN0;
        private System.Windows.Forms.Button bClear;
        private System.Windows.Forms.Button bDecimal;
        private System.Windows.Forms.Button bAdd;
        private System.Windows.Forms.Button bSub;
        private System.Windows.Forms.Button bMul;
        private System.Windows.Forms.Button bDiv;
        private System.Windows.Forms.Button bEqual;
    }
}

