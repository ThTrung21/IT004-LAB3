namespace Bai07
{
    public partial class Form7 : Form
    {
        List<Button> DSChon = new List<Button>();
        int iThanhTien = 0;

        public Form7()
        {
            InitializeComponent();
            textBox1.Enabled = false;
        }

        private void bEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button btn = (Button) sender;

            if (btn.BackColor != Color.Yellow )
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor == Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else
            {
                MessageBox.Show("Cho ngoi da dc chon truoc!");
            }
        }

        private void bChon_Click(object sender, EventArgs e)
        {
            foreach (Button B in DSChon)
            {
                int a = int.Parse(B.Text);
                if (a <= 5)
                {
                    B.BackColor = Color.Yellow;
                    iThanhTien += 5000;
                }
                if (a > 5 && a <= 10)
                {
                    B.BackColor = Color.Yellow;
                    iThanhTien += 6500;
                }
                if (a > 10 && a <= 15)
                {
                    B.BackColor = Color.Yellow;
                    iThanhTien += 8000;
                }
            }
            textBox1.Text = iThanhTien.ToString();
            iThanhTien = 0;
            DSChon = new List<Button>();
        }

        private void bHuy_Click(object sender, EventArgs e)
        {
            foreach(Button B in DSChon)
            {
                B.BackColor= Color.White;

            }
            textBox1.Text = "";
            DSChon = new List<Button>(); 
        }
    }
}